% Ayse KILIC 2444768  
% Omer Faruk VERGISIZ 2445138

classdef Schedule < handle
    properties
        dailyPlanningHorizon
        planningDays
        numberOfRooms
        finalSchedule = {};
        FitCounter = 0;                 % number of operation that are fit their available intervals
        postponedPriorities = [];       % list of priorities that belongs to postponned patients
        fullnessRatios = [];            % fullness ratios of each room
    end

    methods
%% Schedule %%
        function self = Schedule(dailyPlanningHorizon, planningDays, numberOfRooms)
            self.dailyPlanningHorizon = dailyPlanningHorizon;
            self.planningDays = planningDays;
            self.numberOfRooms = numberOfRooms;
        end
%% constructSchedule %%
        function constructSchedule(self)
        %% Importing Datas %%
            excelData = readcell("InputData.xlsx");
            Patients = {};
            fprintf("Importing Datas\n")
            for i = 2:length(excelData)
                Patients{i-1,1} = Patient(excelData{i,1}, excelData{i,2}, excelData{i,3}, excelData{i,4}, excelData{i,5}, excelData{i,6}, excelData{i,7}, excelData{i,8});
                Patients{i-1,2} = excelData{i,7};   % Available Finish
                Patients{i-1,3} = excelData{i,8};   % priority
                Patients{i-1,4} = excelData{i,5};   % duration
                Patients{i-1,5} = excelData{i,4};   % day
                Patients{i-1,6} = excelData{i,6};   % Available Start
                if mod(i,5) == 0; fprintf("█"); end                         % These are for loading screen
            end
            Patients{i,1} = "Cem IYIGUN";                                   % This extra patient needed for previous while loop
            Patients{i,2} = 0;   % Available Finish
            Patients{i,3} = 0;   % priority
            Patients{i,4} = 0;   % duration
            Patients{i,5} = 30;  % day
            Patients{i,6} = 0;   % day
            fprintf("█\n")

            Patients = sortrows(Patients, 4);   % duration
            Patients = sortrows(Patients, 3);   % priority
            %Patients = sortrows(Patients, 2);  % Available Finish
            Patients = sortrows(Patients, 6);   % Available Start
            Patients = sortrows(Patients, 5);   % day

            postponedPatients = [];
            j = 1;
            fprintf("Setting patients to the rooms\n")
            for i = 1:self.planningDays
                Room1 = Interval(self.dailyPlanningHorizon.left, self.dailyPlanningHorizon.right); Room1Counter = 1; Room1Fullness = 0;
                Room2 = Interval(self.dailyPlanningHorizon.left, self.dailyPlanningHorizon.right); Room2Counter = 1; Room2Fullness = 0;
                Room3 = Interval(self.dailyPlanningHorizon.left, self.dailyPlanningHorizon.right); Room3Counter = 1; Room3Fullness = 0;
                %Room4 = Interval(self.dailyPlanningHorizon.left, self.dailyPlanningHorizon.right); Room4Counter = 1; Room4Fullness = 0;%% 
                self.finalSchedule{i, 1} = {};
                self.finalSchedule{i, 2} = {};
                self.finalSchedule{i, 3} = {};
                
                k = size(postponedPatients,1);
                L = k;
                if ~isempty(postponedPatients); postponedPatients = sortrows(postponedPatients, 2); end
        %% setting postponned patients %%
                while ~isempty(postponedPatients) && k ~= L-3%%-4               % It did not read the least patient, so extra patient is save that loop 
                    if    k == L
                        self.finalSchedule{i, 1, 1} = Operation(postponedPatients{k,1}.id, postponedPatients{k,1}.patient, postponedPatients{k,1}.availableInterval, Interval(Room1.left * (Room1.left >= postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.availableInterval.left * (Room1.left < postponedPatients{k,1}.availableInterval.left), Room1.left * (Room1.left >= postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.availableInterval.left * (Room1.left < postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.duration), postponedPatients{k,1}.duration, i, 1);
                        Room1.left = Room1.left * (Room1.left >= postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.availableInterval.left * (Room1.left < postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.duration;
                        Room1Counter = Room1Counter + 1;
                        Room1Fullness = Room1Fullness + postponedPatients{k,1}.duration;
                        
                    elseif k == L - 1
                        self.finalSchedule{i, 2, 1} = Operation(postponedPatients{k,1}.id, postponedPatients{k,1}.patient, postponedPatients{k,1}.availableInterval, Interval(Room2.left * (Room2.left >= postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.availableInterval.left * (Room2.left < postponedPatients{k,1}.availableInterval.left), Room2.left * (Room2.left >= postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.availableInterval.left * (Room2.left < postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.duration), postponedPatients{k,1}.duration, i, 2);
                        Room2.left = Room2.left * (Room2.left >= postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.availableInterval.left * (Room2.left < postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.duration;
                        Room2Counter = Room2Counter + 1;
                        Room2Fullness = Room2Fullness + postponedPatients{k,1}.duration;
                
                    elseif k == L - 2
                        self.finalSchedule{i, 3, 1} = Operation(postponedPatients{k,1}.id, postponedPatients{k,1}.patient, postponedPatients{k,1}.availableInterval, Interval(Room3.left * (Room3.left >= postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.availableInterval.left * (Room3.left < postponedPatients{k,1}.availableInterval.left), Room3.left * (Room3.left >= postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.availableInterval.left * (Room3.left < postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.duration), postponedPatients{k,1}.duration, i, 3);
                        Room3.left = Room3.left * (Room3.left >= postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.availableInterval.left * (Room3.left < postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.duration;
                        Room3Counter = Room3Counter + 1;
                        Room3Fullness = Room3Fullness + postponedPatients{k,1}.duration;
                    %{
                    elseif k == L - 3
                        self.finalSchedule{i, 3, 1} = Operation(postponedPatients{k,1}.id, postponedPatients{k,1}.patient, postponedPatients{k,1}.availableInterval, Interval(Room4.left * (Room4.left >= postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.availableInterval.left * (Room4.left < postponedPatients{k,1}.availableInterval.left), Room4.left * (Room4.left >= postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.availableInterval.left * (Room3.left < postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.duration), postponedPatients{k,1}.duration, i, 3);
                        Room4.left = Room4.left * (Room4.left >= postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.availableInterval.left * (Room4.left < postponedPatients{k,1}.availableInterval.left) + postponedPatients{k,1}.duration;
                        Room4Counter = Room4Counter + 1;
                        Room4Fullness = Room4Fullness + postponedPatients{k,1}.duration;
                    %}
                    end
                    postponedPatients(k,:) = [];
                    k = k - 1;
                end
        %% setting patients to the rooms %%      
                t = 1;
                postponedPatients = {};
                while Patients{j, 5} == i && j ~= size(Patients, 1)
                    if     Room1.left * (Room1.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room1.left < Patients{j, 1}.availableInterval.left) + Patients{j, 1}.duration <= Patients{j, 1}.availableInterval.right
                        %                                   Operation(               id, patient,                       availableInterval, scheduledInterval,                                                         duration, operationDay)
                        self.finalSchedule{i, 1, Room1Counter} = Operation(Patients{j, 1}.id, Patients{j, 1}, Patients{j, 1}.availableInterval, Interval(Room1.left * (Room1.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room1.left < Patients{j, 1}.availableInterval.left), Room1.left * (Room1.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room1.left < Patients{j, 1}.availableInterval.left) + Patients{j, 1}.duration), Patients{j, 1}.duration, i, 1);
                        Room1.left = Room1.left * (Room1.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room1.left < Patients{j, 1}.availableInterval.left) + Patients{j, 1}.duration;
                        Room1Counter = Room1Counter + 1;
                        Room1Fullness = Room1Fullness + Patients{j, 1}.duration;
                        self.FitCounter = self.FitCounter + 1;
                
                    elseif  Room2.left * (Room2.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room2.left < Patients{j, 1}.availableInterval.left) + Patients{j, 1}.duration <= Patients{j, 1}.availableInterval.right
                        self.finalSchedule{i, 2, Room2Counter} = Operation(Patients{j, 1}.id, Patients{j, 1}, Patients{j, 1}.availableInterval, Interval(Room2.left * (Room2.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room2.left < Patients{j, 1}.availableInterval.left), Room2.left * (Room2.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room2.left < Patients{j, 1}.availableInterval.left) + Patients{j, 1}.duration), Patients{j, 1}.duration, i, 2);
                        Room2.left = Room2.left * (Room2.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room2.left < Patients{j, 1}.availableInterval.left) + Patients{j, 1}.duration;
                        Room2Counter = Room2Counter + 1;
                        Room2Fullness = Room2Fullness + Patients{j, 1}.duration;
                        self.FitCounter = self.FitCounter + 1;
                
                    elseif Room3.left * (Room3.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room3.left < Patients{j, 1}.availableInterval.left) + Patients{j, 1}.duration <= Patients{j, 1}.availableInterval.right
                        self.finalSchedule{i, 3, Room3Counter} = Operation(Patients{j, 1}.id, Patients{j, 1}, Patients{j, 1}.availableInterval, Interval(Room3.left * (Room3.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room3.left < Patients{j, 1}.availableInterval.left), Room3.left * (Room3.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room3.left < Patients{j, 1}.availableInterval.left) + Patients{j, 1}.duration), Patients{j, 1}.duration, i, 3);
                        Room3.left = Room3.left * (Room3.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room3.left < Patients{j, 1}.availableInterval.left) + Patients{j, 1}.duration;
                        Room3Counter = Room3Counter + 1;
                        Room3Fullness = Room3Fullness + Patients{j, 1}.duration;
                        self.FitCounter = self.FitCounter + 1;
                        %{
                    elseif Room4.left * (Room4.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room4.left < Patients{j, 1}.availableInterval.left) + Patients{j, 1}.duration <= Patients{j, 1}.availableInterval.right
                        self.finalSchedule{i, 4, Room4Counter} = Operation(Patients{j, 1}.id, Patients{j, 1}, Patients{j, 1}.availableInterval, Interval(Room4.left * (Room4.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room4.left < Patients{j, 1}.availableInterval.left), Room4.left * (Room4.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room4.left < Patients{j, 1}.availableInterval.left) + Patients{j, 1}.duration), Patients{j, 1}.duration, i, 4);
                        Room4.left = Room4.left * (Room4.left >= Patients{j, 1}.availableInterval.left) + Patients{j, 1}.availableInterval.left * (Room4.left < Patients{j, 1}.availableInterval.left) + Patients{j, 1}.duration;
                        Room4Counter = Room4Counter + 1;
                        Room4Fullness = Room4Fullness + Patients{j, 1}.duration;
                        self.FitCounter = self.FitCounter + 1;
                        %}

                    else
                        self.postponedPriorities = [self.postponedPriorities Patients{j, 1}.priority];
                        Patients{j, 1}.setPatientDay(i+1)
                        Patients{j, 1}.setPatientPriority(0)
                        postponedPatients{t,1} = Operation(Patients{j, 1}.id, Patients{j, 1}, Patients{j, 1}.availableInterval, Patients{j, 1}.availableInterval, Patients{j, 1}.duration, i+1,0);
                        postponedPatients{t,1}.setAvailableInterval(Interval(0,Patients{j, 1}.duration))
                        postponedPatients{t,1}.setScheduledInterval(Interval(0,Patients{j, 1}.duration))
                        postponedPatients{t,2} = Patients{j, 1}.duration;
                        t = t + 1;
                    end
                    j = j + 1;
                    if mod(j,5) == 0; fprintf("█"); end
                end
                self.fullnessRatios = [self.fullnessRatios; [Room1Fullness/480, Room2Fullness/480, Room3Fullness/480]];%%, Room4Fullness/480]];
            end
            fprintf("█\n")
        end
%% printSchedule %%
        function printSchedule(self)
        %% Gantt Chart %%
            fprintf("Preparing Gantt Charts\n")
            for i = 1:self.planningDays
                fprintf("█")
                figure('Name',"Day "+int2str(i),'NumberTitle','off', 'Color', 'w');
                t = tiledlayout(self.numberOfRooms,1);
                title(t, "Day "+int2str(i))
                xlabel(t, "times (""min"")")
                for j = 1:self.numberOfRooms
                    nexttile
                    plot([0,480],[0,0], "LineStyle",":","Color",[36, 113, 163]/255)         
                    for x = 0:20:480; text(x,5,int2str(x),"Color",[36, 113, 163]/255,"HorizontalAlignment","left","VerticalAlignment","middle","FontSize",8,"Rotation",90); end
                    hold on 
                    for k = 1:numOperation(self, i, j)
                        text(-80,-20*k,"Patient "+int2str(self.finalSchedule{i,j,k}.id),"Color",[36, 113, 163]/255,"HorizontalAlignment","left","VerticalAlignment","bottom","FontSize",8),
                        fill([self.finalSchedule{i,j,k}.scheduledInterval.left,self.finalSchedule{i,j,k}.scheduledInterval.right,self.finalSchedule{i,j,k}.scheduledInterval.right,self.finalSchedule{i,j,k}.scheduledInterval.left],[-20*k,-20*k,-20*(k-1),-20*(k-1)],[23, 165, 137]/255)
                        plot([self.finalSchedule{i,j,k}.availableInterval.left,self.finalSchedule{i,j,k}.availableInterval.right,self.finalSchedule{i,j,k}.availableInterval.right,self.finalSchedule{i,j,k}.availableInterval.left,self.finalSchedule{i,j,k}.availableInterval.left],[-20*k,-20*k,-20*(k-1),-20*(k-1),-20*k],"LineWidth",1.5,"Color","k")
                        for x = 0:20:480; plot([x x],[-20*(k-1),-20*k], "LineStyle",":","Color",[36, 113, 163]/255); hold on; end
                        plot([0,480],[-20*k,-20*k], "LineStyle",":","Color",[36, 113, 163]/255)
                        title("Room "+int2str(j))
                        hold on
                    end
                    text(0, -20*(k+1), "The utilization of the room is = %"+num2str(self.fullnessRatios(i,j)*100, 2),"Color",[36, 113, 163]/255,"FontSize",10)
                    fprintf("█")
                    axis equal
                    xlim([-100,500])
                    ylim([-225,50])
                end
            end
            fprintf("\n")
        %% Excel File %%
            fprintf("Preparing excel file\n")
            listOfPatients = reshape(self.finalSchedule,[],1);
            k = length(listOfPatients);
            i = 1;
            j = 1;
            while i <= k
                if isempty(listOfPatients{j})
                    listOfPatients(j) = [];
                    j = j - 1;
                end
                j = j + 1;
                i = i + 1;
            end
            
            for i = 1:length(listOfPatients)
                listOfPatients{i,2} = listOfPatients{i,1}.id;
            end
            listOfPatients = sortrows(listOfPatients, 2);
                RoomNo            = [];
                AvailableInterval = {};
                Duration          = [];
                ScheduledInterval = {};
                PatientName       = {};
                PatientSurname    = {};
                PatientPriority   = [];
                OperationDay      = [];
            for i = 1:length(listOfPatients)
                RoomNo            = [RoomNo; listOfPatients{i,1}.operationRoom];
                AvailableInterval{i,1} = "("+num2str(listOfPatients{i,1}.availableInterval.left)+","+num2str(listOfPatients{i,1}.availableInterval.right)+")";
                Duration          = [Duration; listOfPatients{i,1}.duration];
                ScheduledInterval{i,1} = "("+num2str(listOfPatients{i,1}.scheduledInterval.left)+","+num2str(listOfPatients{i,1}.scheduledInterval.right)+")";
                PatientName{i,1}       = listOfPatients{i,1}.patient.name;
                PatientSurname{i,1}    = listOfPatients{i,1}.patient.surname;
                PatientPriority   = [PatientPriority; listOfPatients{i,1}.patient.priority];
                OperationDay      = [OperationDay; listOfPatients{i,1}.operationDay];
                if mod(i,5) == 0; fprintf("█"); end
            end
            T = table(RoomNo, AvailableInterval, Duration, ScheduledInterval, PatientName, PatientSurname, PatientPriority, OperationDay);
            writetable(T,"output.xlsx")
            fprintf("███\n\n")
        end
%% printReport %%
        function printReport(self)  % fprintf format output
            fprintf("scheduled_objective_2 function value = %d\n\n", self.FitCounter)
            fprintf("utilization of the rooms:\n")
            fprintf("Days   |")
            for i = 1:self.planningDays; fprintf("  %d  |", i); end; fprintf(" Avg |\n")
            fprintf("Rooms  ____________________________________|\n")
            for i = 1:self.numberOfRooms
                fprintf("  %d    |",i); for j = 1:self.planningDays; fprintf(" %%%.0f |", self.fullnessRatios(j,i)*100); end
                average = 0;
                for j = 1:self.planningDays; average = average + self.fullnessRatios(j,i)*100; end
                fprintf(" %%%.0f |\n", average/5)
            end
            fprintf("Average|")
            for i = 1:self.planningDays
                average = 0;
                for j = 1:self.numberOfRooms
                    average = average + self.fullnessRatios(i,j)*100;
                end
                fprintf(" %%%.0f |", average/3)%4)
            end
            fprintf("\n\n")
            fprintf("the number of operations shifted in each priority levels:\n")
            fprintf(" priority levels | # of shifts |\n")
            total = 0;
            for i = 1:4; fprintf("        %d        |      %d      |\n", i, length(find(self.postponedPriorities == i))); total = total + length(find(self.postponedPriorities == i)); end
            fprintf("\nthe number of operations that are postponed to the next day = %d\n", total)
        end
%% numOperation %%
        function  i = numOperation(self, dayNum, roomNum)       % It counts how many patients in the specify room
            i = 0;
            for j = 1:size(self.finalSchedule, 3)
                if isa(self.finalSchedule{dayNum, roomNum, j}, "Operation")
                    i = i + 1;
                end
            end
        end
    end
end

