% Ayse KILIC 2444768  
% Omer Faruk VERGISIZ 2445138
clear classes
clear all
clc

dailyPlanningHorizon = Interval(0, 480); 
planningDays         = 5;
numberOfRooms        = 3;%4 It is not a generic code for "numberOfRooms". Some comment signs has to be removed for 4 number of rooms.
Sc = Schedule(dailyPlanningHorizon, planningDays, numberOfRooms);
Sc.constructSchedule()
Sc.printSchedule()      % Gantt Chart and Excel File
Sc.printReport()        % fprintf format