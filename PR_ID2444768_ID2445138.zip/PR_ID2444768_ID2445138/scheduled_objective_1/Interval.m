% Ayse KILIC 2444768  
% Omer Faruk VERGISIZ 2445138

classdef Interval < handle
% An Interval has a left endpoint and a right endpoint.
    
    properties
       left
       right
    end
    
    methods
        % Constructor:  construct an Interval object
        function Inter = Interval(lt, rt) 
            Inter.left= lt;
            Inter.right= rt;
        end
        
        % Return the width of the Interval
        function w = getWidth(self) 
            w = self.right - self.left;
        end
        
        % Scale self by a factor f
        function scale(self, f)
            w = getWidth(self);
            self.right = self.left + w * f;
        end
        
        % Shift self by constant s
        function shift(self, s)
            self.right = self.right + s;
            self.left = self.left + s;
        end
        
        % tf is true (1) if self is in the other Interval
        function tf = isIn(self, other)
            tf = 0;
            if other.left <= self.left && self.right <= other.right
                tf = 1;
            end
        end
        
        % Inter is the new Interval formed by adding self and the the other Interval{
        function Inter = add(self, other)
            Inter = Interval(min(self.left, other.left), max(self.right, other.right));
        end

        % Display self, if not empty, in this format: (left,right)
        % If empty, display 'Empty <classname>'
        function disp(self)
            if isempty(self)
                fprintf('Empty %s\n', class(self))
            else
                fprintf('(%f,%f)\n', self.left, self.right)
            end
        end
        
        % tf is true (1) if self and other Intervals are overlap
        function tf = isoverlap(self, other)
            tf = 0;
            if (other.left <= self.right  && self.left   <= other.right) ||...  
               (self.left  <= other.right && other.left  <= self.right ) ||...  
               (self.left  <= other.left  && other.right <= self.right ) ||...  
               (other.left <= self.left   && self.right  <= other.right)        
                tf = 1;
            end
        end
        
    end %methods
    
end %classdef