% Ayse KILIC 2444768  
% Omer Faruk VERGISIZ 2445138

classdef Operation < handle
    properties
        id
        patient
        availableInterval
        scheduledInterval
        duration
        operationDay
        operationRoom
    end

    methods
        function self = Operation(id, patient, availableInterval, scheduledInterval, duration, operationDay,operationRoom)
            self.id = id;
            self.patient = patient;
            self.availableInterval = availableInterval;
            self.scheduledInterval = scheduledInterval;
            self.duration = duration;
            self.operationDay = operationDay;
            self.operationRoom = operationRoom;
        end
        
        function setScheduledInterval(self, scheduledInterval)
            self.scheduledInterval = scheduledInterval;
        end

        function setAvailableInterval(self, availableInterval)
            self.availableInterval = availableInterval;
        end
    end
end 


