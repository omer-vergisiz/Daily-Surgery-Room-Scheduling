% Ayse KILIC 2444768  
% Omer Faruk VERGISIZ 2445138

classdef Patient < handle
    properties
        id
        name
        surname
        day
        duration
        availableInterval
        priority
    end

    methods
        function self = Patient(id, name, surname, day, duration, left, right, priority)
            self.id = id;
            self.name = name;
            self.surname = surname;
            self.day = day;
            self.duration = duration;
            self.availableInterval = Interval(left, right);
            self.priority = priority;
        end

        function p = getPatientPriority(self)
            p = self.priority;
        end

        function setPatientPriority(self, p)
            self.priority = p;
        end

        function d = getPatientDay(self)
            d = self.day;
        end

        function setPatientDay(self, d)
            self.day = d;
        end
    end
end